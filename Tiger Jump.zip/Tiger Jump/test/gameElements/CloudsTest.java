package gameElements;

import org.junit.Test;

import java.awt.*;

public class CloudsTest {
	@Test
	public void testDraw() {
		// Setup
		final Graphics g = null;

		// Run the test
		Clouds cloudsUnderTest = new Clouds();
		cloudsUnderTest.draw(g);

		// Verify the results
	}

	@Test
	public void testUpdate() {
		// Setup

		// Run the test
		Clouds cloudsUnderTest = new Clouds();
		cloudsUnderTest.update();

		// Verify the results
	}
}
