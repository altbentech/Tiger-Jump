package gameElements;

import org.junit.Test;

import java.awt.*;

public class ObstacleSettingsTest {

	@Test
	public void testDraw() {
		// Setup
		final Graphics g = null;

		// Run the test
		ObstacleSettings obstacleSettingsUnderTest = null;
		obstacleSettingsUnderTest.draw(g);

		// Verify the results
	}

	@Test
	public void testReset() {
		// Setup

		// Run the test
		ObstacleSettings obstacleSettingsUnderTest = null;
		obstacleSettingsUnderTest.reset();

		// Verify the results
	}

	@Test
	public void testUpdate() {
		// Setup

		// Run the test
		ObstacleSettings obstacleSettingsUnderTest = null;
		obstacleSettingsUnderTest.update();

		// Verify the results
	}
}
