package gameElements;

import org.junit.Test;

import java.awt.*;

public class GroundTest {

	@Test
	public void testDraw() {
		// Setup
		final Graphics g = null;

		// Run the test
		Ground groundUnderTest = null;
		groundUnderTest.draw(g);

		// Verify the results
	}

	@Test
	public void testUpdate() {
		// Setup

		// Run the test
		Ground groundUnderTest = null;
		groundUnderTest.update();

		// Verify the results
	}
}
