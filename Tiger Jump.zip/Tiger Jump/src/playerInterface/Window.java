package playerInterface;

import javax.swing.*;

public class Window extends JFrame{
	
	private final Screen Screen;

	{
		Screen = new Screen();
	}

	public Window() {
		super("Tiger Jump"); // displays the title of the window
		setSize(600, 155); // sets the size of the window
		setResizable(false); // makes the window not resizable
		setLocation(400, 200); // set the position of the window in the player's monitor
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // to exit the code when the window is closed
		add(Screen);
		addKeyListener(Screen); // to control the game using keys
	}
	
	public void startGame() {
		Screen.startGame();
	}
	
	public static void main(String[] args) {
		Window gw = new Window();
		gw.setVisible(true); // allows the window to be visible in the screen
		gw.startGame(); // start of the game
	}
	
	
}
