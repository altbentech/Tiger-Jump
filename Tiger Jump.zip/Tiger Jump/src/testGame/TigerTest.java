package testGame;

import static org.junit.Assert.*;

import org.junit.Test;

public class TigerTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
